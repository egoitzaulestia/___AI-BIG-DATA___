library(shiny)

ui=fluidPage("Hellow world")

server=function(input, output){
}

shinyApp(ui = ui, server = server)

