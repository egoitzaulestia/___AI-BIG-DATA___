library(shiny)

ui = fluidPage(
  sliderInput(inputId = "num",
              label = "Selecciona un numero",
              value = 100, min = 1, max = 100),
  actionButton(inputId = "go",
               label = "update"),
  
  plotOutput("Histograma")
)


server = function(input, output){
  
  data = eventReactive(input$go,{
    a = rnorm(input$num)
    print(a)
  })

  observeEvent(input$go, {
    print(as.numeric(input$go))
    })
    
  output$Histograma = renderPlot({
    hist(data())
  })
}


shinyApp(ui = ui, server = server)