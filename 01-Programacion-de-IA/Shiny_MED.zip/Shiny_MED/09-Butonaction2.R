library(shiny)

ui=fluidPage(
  actionButton(inputId = "clicks",
              label = "clickme"),
  plotOutput("hist"),
  plotOutput("hist2"),
  
)

server = function(input, output){
  observeEvent(input$clicks, {
    print(as.numeric(input$clicks))
    output$hist = renderPlot({
      hist(rnorm(78))
    })
    output$hist2 = renderPlot({
      hist(rnorm(78))
    })
  })
}

shinyApp(ui = ui, server = server)