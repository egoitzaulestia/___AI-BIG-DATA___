datos = read.csv("train.csv")

View(datos)