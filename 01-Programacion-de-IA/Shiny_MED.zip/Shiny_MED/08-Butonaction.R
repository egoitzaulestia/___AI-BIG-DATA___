library(shiny)

ui=fluidPage(
  actionButton(inputId = "clicks",
              label = "clickme")
)

server = function(input, output){
  
  
  
}

shinyApp(ui = ui, server = server)