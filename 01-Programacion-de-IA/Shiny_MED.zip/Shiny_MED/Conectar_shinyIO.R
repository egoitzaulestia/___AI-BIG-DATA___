

# Conectar con mi espacio.
install.packages('rsconnect')

# Conectar con mi espacio.
rsconnect::setAccountInfo(name='', 
                          token='', 
                          secret='')


library(rsconnect)

